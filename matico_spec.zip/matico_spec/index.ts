import * as wasm from "./pkg/matico_spec_bg.wasm";
export * from "./pkg/matico_spec_bg.js";
