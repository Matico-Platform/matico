import * as wasm from "./matico_spec_bg.wasm";
export * from "./matico_spec_bg.js";