const esbuild = require('esbuild')
const options  = require("./options")

esbuild.build(options)
